`ipretty.el' provides interactive functions to pretty-print the
result of an expression and a global mode `ipretty-mode' that
advices `eval-print-last-sexp' to pretty print.
