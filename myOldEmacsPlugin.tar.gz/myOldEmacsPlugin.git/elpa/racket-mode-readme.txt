Goals:
- Focus on Racket (not various Schemes).
- Follow DrRacket concepts where applicable.
- Thorough font-lock and indent.
- Compatible with Emacs 24.3+ and Racket 5.3.5+.

Details: https://github.com/greghendershott/racket-mode
